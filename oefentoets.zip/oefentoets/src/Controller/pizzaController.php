<?php

namespace App\Controller;

use App\Entity\Category;
use App\Entity\Klant;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class pizzaController extends AbstractController
{
    /**
     * @Route ("/categories")
     */

    public function categories(EntityManagerInterface $em){
        $cats=$em->getRepository(Category::class)->findAll();
        $klant=$em->getRepository(Klant::class)->findAll();

        return $this->render('home.html.twig',[
            'cats'=>$cats,
            'klant'=>$klant,
        ]);
    }
}